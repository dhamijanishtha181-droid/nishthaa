STATIC PERSONAL WEBSITE
=======================

FILES
- index.html  : Website structure and content
- style.css   : Colours, layout, responsive design, and styling
- script.js   : Mobile navigation and automatic footer year

HOW TO OPEN
1. Extract the ZIP file.
2. Open the folder.
3. Double-click index.html to open it in your browser.

HOW TO CUSTOMISE
- Replace "Your Name" and "YN" with your own name and initials in index.html.
- Update the About, Skills, Projects, email, location, and LinkedIn details.
- Change colours near the top of style.css under :root.
- You can edit these files using Notepad, VS Code, or another text editor.

NOTE
This is a static website. It does not require a server or database. The contact section uses editable sample details and does not submit a message form.
